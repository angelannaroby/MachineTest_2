Done as part of machine test conducted by Simelabs
API: Open AQ
Done By : Angel Anna Roby
