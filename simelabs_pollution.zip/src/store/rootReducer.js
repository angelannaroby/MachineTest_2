import { combineReducers } from "redux";
import latestData from "./reducers/reducers";

export default combineReducers({
    latestData
});
